# ANGEL 3 Production Website

เว็บไซต์บริษัทขายน้ำมัน 4 หน้า พร้อมใช้งาน:
- index.html
- about.html
- products.html
- contact.html

## เปิดดูบนเครื่อง
เปิดไฟล์ index.html

## อัปโหลดขึ้น GitHub / Cloudflare Pages
อัปโหลดทุกไฟล์ในโฟลเดอร์นี้ไปยัง repository
Cloudflare Pages:
- Framework preset: None
- Build command: เว้นว่าง
- Output directory: /

## ข้อมูลที่ควรเพิ่มก่อนเปิดจริง
- อีเมลบริษัท
- LINE Official
- เลขประจำตัวผู้เสียภาษี (ถ้าต้องการ)
- โดเมนที่ซื้อแล้ว


## ข้อมูลติดต่อปัจจุบัน
- Tel: 081-894-9898
- LINE ID: angel.tree.co.ltd
